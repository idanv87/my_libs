import numpy as np
import matplotlib.pyplot as plt

def add(x):
    print(x)
